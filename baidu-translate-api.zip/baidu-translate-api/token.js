const request = require('request');
//proxy="http://10.165.7.48:808"
var _proxy;

function getToken() {
    var options = {
        headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Host': 'fanyi.baidu.com',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'
        }
    };
    _proxy && (options.proxy = _proxy);
    return new Promise(function (resolve, reject) {
        request.get("https://fanyi.baidu.com", options, function (error, response, body) {
            // console.log('error:', error); // Print the error if one occurred
            // console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            // console.log('body:', body); // Print the HTML for the Google homepage.
            if (error) {
                reject(error);
            } else {
                if (response && response.statusCode === 200) {
                    //resolve(body);
                    var tokens = {};
                    var regexResult = /token\s*:\s*\'([^\']*)\'/ig.exec(body);
                    if (regexResult && regexResult.length > 1) {
                        tokens.commonToken = regexResult[1];
                    }
                    regexResult = /window\.gtk\s*=\s*\'([^\']*)\'/ig.exec(body);
                    if (regexResult && regexResult.length > 1) {
                        tokens.gtk = regexResult[1];
                    }
                    if (tokens.commonToken && tokens.gtk) {
                        resolve(tokens);
                    } else {
                        reject(new Error('get token error'));
                    }
                } else {
                    reject(new Error('request error:' + (response && response.statusCode)));
                }
            }
        })
    })
};
module.exports.setProxy = function (proxy) {
    if (proxy) {
        _proxy = proxy;
    }
}
module.exports.get = getToken;