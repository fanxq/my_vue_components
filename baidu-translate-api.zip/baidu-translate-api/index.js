const token = require("./token");
const sign = require("./sign");
const request = require("request");
var proxy = "http://10.165.7.48:808";
token.setProxy(proxy);
token.get().then(function (result) {
    console.log(result);
    var queryStr = '测试';
    request.post('https://fanyi.baidu.com/v2transapi', {
        form: {
            from: 'zh',
            to: 'en',
            query: encodeURIComponent(queryStr),
            transtype: 'realtime',
            simple_means_flag: 3,
            sign: sign(queryStr, result.gtk),
            token: result.commonToken
        },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36',
            // 'Referer': 'https://fanyi.baidu.com/',
            // 'Origin': 'https://fanyi.baidu.com'
        },
        proxy: proxy
    }, function (error, response, body) {
        if (error) {
            throw error;
        }
        if (response && response.statusCode === 200) {
            console.log(body);
        }
    })
}).catch(function (err) {
    console.log(err);
})